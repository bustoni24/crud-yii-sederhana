<?php

/**
 * This is the model class for table "data_lampu".
 *
 * The followings are the available columns in table 'data_lampu':
 * @property integer $data_lampu_id
 * @property string $kode
 * @property integer $detail_lampu
 * @property integer $daya
 * @property integer $jenis_tiang
 * @property integer $kecamatan_id
 * @property integer $dusun_id
 * @property string $lat
 * @property string $lng
 * @property string $tanggal_pasang
 * @property integer $kwh_meter
 * @property string $id_ruas_jalan
 * @property string $jenis_jalan
 * @property string $status_jalan
 * @property string $keterangan
 * @property integer $is_legal
 */
class DataLampu extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'data_lampu';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('detail_lampu, daya, kecamatan_id, dusun_id, kwh_meter, is_legal', 'numerical', 'integerOnly'=>true),
			array('kode, lat, lng,jenis_tiang', 'length', 'max'=>30),
			array('id_ruas_jalan, nama_jalan', 'length', 'max'=>50),
			array('kelas_jalan, status_jalan', 'length', 'max'=>20),
			array('tanggal_pasang, keterangan', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('data_lampu_id, kode, detail_lampu, daya, jenis_tiang, kecamatan_id, dusun_id, lat, lng, tanggal_pasang, kwh_meter, id_ruas_jalan, jenis_jalan, status_jalan, keterangan, is_legal', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'data_lampu_id' => 'Data Lampu',
			'kode' => 'Kode',
			'detail_lampu' => 'Detail Lampu',
			'daya' => 'Daya',
			'jenis_tiang' => 'Jenis Tiang',
			'kecamatan_id' => 'Kecamatan',
			'dusun_id' => 'Dusun',
			'lat' => 'Lat',
			'lng' => 'Lng',
			'tanggal_pasang' => 'Tanggal Pasang',
			'kwh_meter' => 'Kwh Meter',
			'id_ruas_jalan' => 'Id Ruas Jalan',
			'kelas_jalan' => 'Kelas Jalan',
			'status_jalan' => 'Status Jalan',
			'keterangan' => 'Keterangan',
			'is_legal' => 'Is Legal',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('data_lampu_id',$this->data_lampu_id);
		$criteria->compare('kode',$this->kode,true);
		$criteria->compare('detail_lampu',$this->detail_lampu);
		$criteria->compare('daya',$this->daya);
		$criteria->compare('jenis_tiang',$this->jenis_tiang);
		$criteria->compare('kecamatan_id',$this->kecamatan_id);
		$criteria->compare('dusun_id',$this->dusun_id);
		$criteria->compare('lat',$this->lat,true);
		$criteria->compare('lng',$this->lng,true);
		$criteria->compare('tanggal_pasang',$this->tanggal_pasang,true);
		$criteria->compare('kwh_meter',$this->kwh_meter);
		$criteria->compare('id_ruas_jalan',$this->id_ruas_jalan,true);
		$criteria->compare('kelas_jalan',$this->kelas_jalan,true);
		$criteria->compare('status_jalan',$this->status_jalan,true);
		$criteria->compare('keterangan',$this->keterangan,true);
		$criteria->compare('is_legal',$this->is_legal);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DataLampu the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
