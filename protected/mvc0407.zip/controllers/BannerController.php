<?php

class BannerController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			//'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',
				'actions'=>array('index','admin','create', 'update','delete', 'view', 'sort', 'deleteImage', 'compress'),
				'expression'=>'isset(Yii::app()->user->permission) && (in_array("banner",Yii::app()->user->permission))',
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new Banner;
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Banner']))
		{
			if($_FILES["Banner"]['name']["image_url"]!='')
			{
				$name = explode('.',$_FILES["Banner"]['name']["image_url"]);
				$dir = Yii::app()->basePath.'/banners/';
				$dir = str_replace('protected','uploads',$dir);
				$fileName = date('YmdHis').'.'.$name[1];
				move_uploaded_file($_FILES["Banner"]['tmp_name']["image_url"],$dir.$fileName);
				$_POST['Banner']['image_url']=$fileName;
				//$this->compress($dir.$fileName);
			}
			
			$model->attributes=$_POST['Banner'];
			//if($_POST['Banner']['type']==1){
			//	$model->service_type = 0;
			//}
			$model->created_date = date('Y-m-d H:i:s');
			if($model->save()){
				$this->redirect(array('admin'));
			}
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Banner']))
		{
			if($_FILES["Banner"]['name']["image_url"]!='')
			{
				$name = explode('.',$_FILES["Banner"]['name']["image_url"]);
				$dir = Yii::app()->basePath.'/banners/';
				$dir = str_replace('protected','uploads',$dir);
				$fileName = date('YmdHis').'.'.$name[1];
				move_uploaded_file($_FILES["Banner"]['tmp_name']["image_url"],$dir.$fileName);
				$_POST['Banner']['image_url']=$fileName;

				//$this->compress($dir.$fileName);
			}else{
				unset($_POST['Banner']['image_url']);
			}
					
			$model->attributes=$_POST['Banner'];
			
			if($model->save())
				$this->redirect(array('admin'));
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$this->actionAdmin();
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new Banner('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Banner']))
			$model->attributes=$_GET['Banner'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}

	private function compress($path){
		Yii::import("application.vendor.*");
		include("autoload.php");
		try{
			Tinify\setKey("j_VWKDat05DcVLkVWoqtZJE-aZuXOFNh");
			Tinify\fromFile($path)->toFile($path); // ."_compressed.".end(explode('.',$path))
		
			/*
			// cari file di dalam folder		
			$dir = Yii::app()->basePath.'/doc_upload/';
			$dir = str_replace('protected','uploads',$dir);
		  	$files = array_diff(scandir($dir."44201801", 0), array('.', '..'));
		 	natsort($files);
			if(count($files) > 0){	
				$i = 0;
				foreach($files as $r){
					if($r != "index.html"){
						Tinify\fromFile($dir."44201801/".$r)->toFile($dir."44201801/".$r."_compressed.png");
					}
				}

			}
		  */
		
		}catch(Exception $e){
			print_r($e);
		}

	}
	
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Banner the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Banner::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Banner $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='banner-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
