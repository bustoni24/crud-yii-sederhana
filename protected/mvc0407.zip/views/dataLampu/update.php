<?php
/* @var $this DataLampuController */
/* @var $model DataLampu */

$this->breadcrumbs=array(
	'Data Lampus'=>array('index'),
	$model->data_lampu_id=>array('view','id'=>$model->data_lampu_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List DataLampu', 'url'=>array('index')),
	array('label'=>'Create DataLampu', 'url'=>array('create')),
	array('label'=>'View DataLampu', 'url'=>array('view', 'id'=>$model->data_lampu_id)),
	array('label'=>'Manage DataLampu', 'url'=>array('admin')),
);
?>

<h1>Update DataLampu <?php echo $model->data_lampu_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>