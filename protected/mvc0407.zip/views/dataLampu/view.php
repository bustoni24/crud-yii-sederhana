<?php
/* @var $this DataLampuController */
/* @var $model DataLampu */

$this->breadcrumbs=array(
	'Data Lampus'=>array('index'),
	$model->data_lampu_id,
);

$this->menu=array(
	array('label'=>'List DataLampu', 'url'=>array('index')),
	array('label'=>'Create DataLampu', 'url'=>array('create')),
	array('label'=>'Update DataLampu', 'url'=>array('update', 'id'=>$model->data_lampu_id)),
	array('label'=>'Delete DataLampu', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->data_lampu_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage DataLampu', 'url'=>array('admin')),
);
?>

<h1>View DataLampu #<?php echo $model->data_lampu_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'data_lampu_id',
		'kode',
		'detail_lampu',
		'daya',
		'jenis_tiang',
		'kecamatan_id',
		'dusun_id',
		'lat',
		'lng',
		'tanggal_pasang',
		'kwh_meter',
		'id_ruas_jalan',
		'jenis_jalan',
		'status_jalan',
		'keterangan',
		'is_legal',
	),
)); ?>
