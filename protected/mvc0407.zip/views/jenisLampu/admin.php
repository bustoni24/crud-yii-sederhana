<?php
/* @var $this JenisLampuController */
/* @var $model JenisLampu */

$this->breadcrumbs=array(
	'Jenis Lampus'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'List JenisLampu', 'url'=>array('index')),
	array('label'=>'Create JenisLampu', 'url'=>array('create')),
);

?>

<h1>Jenis Lampu</h1>


<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'jenis-lampu-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'ref_lampu_id',
		'jenis_lampu',
		'keterangan',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
