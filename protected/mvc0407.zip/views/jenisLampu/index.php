<?php
/* @var $this JenisLampuController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Jenis Lampus',
);

$this->menu=array(
	array('label'=>'Create JenisLampu', 'url'=>array('create')),
	array('label'=>'Manage JenisLampu', 'url'=>array('admin')),
);
?>

<h1>Jenis Lampus</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
