<?php
/* @var $this JenisLampuController */
/* @var $model JenisLampu */

$this->breadcrumbs=array(
	'Jenis Lampus'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List JenisLampu', 'url'=>array('index')),
	array('label'=>'Manage JenisLampu', 'url'=>array('admin')),
);
?>

<h1>Create JenisLampu</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>