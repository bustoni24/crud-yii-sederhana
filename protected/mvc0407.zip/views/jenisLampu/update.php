<?php
/* @var $this JenisLampuController */
/* @var $model JenisLampu */

$this->breadcrumbs=array(
	'Jenis Lampus'=>array('index'),
	$model->ref_lampu_id=>array('view','id'=>$model->ref_lampu_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List JenisLampu', 'url'=>array('index')),
	array('label'=>'Create JenisLampu', 'url'=>array('create')),
	array('label'=>'View JenisLampu', 'url'=>array('view', 'id'=>$model->ref_lampu_id)),
	array('label'=>'Manage JenisLampu', 'url'=>array('admin')),
);
?>

<h1>Update JenisLampu <?php echo $model->ref_lampu_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>