<?php
//$this->layout = "map";

?>
<!DOCTYPE html>
<!--
Template Name: Corklow
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
    <head>
        <title>LPJU Kab. Sleman</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <link href="<?php echo Yii::app()->request->baseUrl; ?>/layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
        <link href="<?php echo Yii::app()->request->baseUrl; ?>/css/bootstrap-responsive.css" rel="stylesheet">
        <script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/js/markerclusterer_packed.js"></script>
        <script src="<?php echo Yii::app()->request->baseUrl; ?>/js/jquery.js"></script>
    </head>
    <body id="top">
        <!-- ################################################################################################ -->
        <!-- ################################################################################################ -->
        <!-- ################################################################################################ -->
        <div class="wrapper row0">
            <div id="topbar" class="hoc clear"> 
                <!-- ################################################################################################ -->
                <div class="fl_left">
                    <ul class="nospace">
                        <li><i class="fa fa-phone"></i> (0274) 3456 7890</li>
                        <li><i class="fa fa-envelope-o"></i> info@domain.com</li>
                    </ul>
                </div>
                <div class="fl_right">
                    <ul class="nospace">
                        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/"><i class="fa fa-lg fa-home fa-2x"></i></a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/site/login" class="btn bnt-mini btn-info">Login</a></li>
                    </ul>
                </div>
                <!-- ################################################################################################ -->
            </div>
        </div>
        <!-- ################################################################################################ -->
        <!-- ################################################################################################ -->
        <!-- ################################################################################################ -->
        <div class="wrapper row1">
            <header id="header" class="hoc clear"> 
                <!-- ################################################################################################ -->
                <div id="logo" class="fl_left">
                    <h1><a href="<?php echo Yii::app()->request->baseUrl; ?>">LPJU Kabupaten Sleman</a></h1>
                    <p>Daerah Istimewa Yogyakarta</p>
                    <br>
                    <!--<a href="#" onClick="setCenter()">set center</a>-->
                </div>

            </header>
        </div>
        <!-- load googlemaps api dulu -->
        <script src="http://maps.google.com/maps/api/js?key=AIzaSyAI17RUIsGWHia52XJmzQb8lu-QnNm-iyg"></script>
        <script type="text/javascript">
            var peta;
            var gambar_tanda;
            gambar_tanda = '<?php echo Yii::app()->request->baseUrl; ?>/images/marker.png';
            var x = new Array();
            var y = new Array();

            var nama = [];
            var kecamatan = [];
            var alamat = [];
            var keterangan = [];
            var status_lokasi = [];
            var lokasi = [];
            var cords = '';
            var area = [];
            var infoWindow;
            var bufferCords = [];
            var livePolyline;

            function peta_awal() {
                // posisi default peta saat diload
                var lokasibaru = new google.maps.LatLng(-7.618955, 110.388130);
                var petaoption = {
                    zoom: 11,
                    center: lokasibaru,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                peta = new google.maps.Map(document.getElementById("map_canvas"), petaoption);
                // memanggil function ambilpeta() untuk menampilkan koordinat
                ambilpeta();
            }

            function setCenter() {
                var lokasibaru = new google.maps.LatLng(-6.618955, 106.388130);
                peta.setCenter(lokasibaru);

            }

            function ambilpeta() {
                 var markers = [];
                <?php 
                    $i = 0;
                    foreach($data as $r){ ?>
                        var point = new google.maps.LatLng(parseFloat(<?php echo $r->lat;?>), parseFloat(<?php echo $r->lng;?>));
                        tanda<?php echo $i;?> = new google.maps.Marker({
                                position: point,
                                map: peta,
                                icon: gambar_tanda,
                                clickable: true
                            });
                        <?php 
                        echo "var contentString".$i." = '<div id=\"content\">'+
			    '<div id=\"siteNotice\">'+
			    '</div>'+
			    '<h2>".$r->kode."</h2>'+
			    '<div id=\"bodyContent\">'+			    
			    'Nama Jalan : ".$r->nama_jalan."<br>'+
			    '</div>'+
			    '</div>';

			var infowindow".$i." = new google.maps.InfoWindow({
			  content: contentString".$i."
			})"; 
                        ?>    
                       tanda<?php echo $i;?>.addListener('click', function() {
			  infowindow<?php echo $i;?>.open(peta, tanda<?php echo $i;?>);
			});        
                        markers.push(tanda<?php echo $i;?>);
                <?php 
                    
                    $i++;
                
                    } ?>                
                
                var markerCluster = new MarkerClusterer(peta, markers,
                                {imagePath: '<?php echo Yii::app()->request->baseUrl; ?>/images/marker/m'});
                            
//                url = "<?php echo Yii::app()->request->baseUrl; ?>/front/data";
//                $.ajax({
//                    url: url,
//                    dataType: 'json',
//                    cache: false,
//                    success: function (msg) {
//                        var markers = [];
//                        for (i = 0; i < msg.lpju.cabang.length; i++) {
//                            x[i] = msg.lpju.cabang[i].x;
//                            y[i] = msg.lpju.cabang[i].y;
//                            var point = new google.maps.LatLng(parseFloat(msg.lpju.cabang[i].x), parseFloat(msg.lpju.cabang[i].y));
//                            tanda = new google.maps.Marker({
//                                position: point,
//                                map: peta,
//                                icon: gambar_tanda,
//                                clickable: true
//                            });
//                            markers.push(tanda);
//                        }
//                        var markerCluster = new MarkerClusterer(peta, markers,
//                                {imagePath: '<?php echo Yii::app()->request->baseUrl; ?>/images/marker/m'});
//                    }
//                });
            }

            var addMode = 0;

        </script> 
    </head>
<body onload="peta_awal()">

    <div id="map_canvas" style="height:400px"></div>

    <footer>
        <p>&copy; adi 2017</p>

    </footer>
</div>


</body>
</html>

