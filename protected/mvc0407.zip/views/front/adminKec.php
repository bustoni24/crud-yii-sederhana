<?php
$this->layout = "front";

?>
<style>
    table a, #comments a {
           background-color: transparent !important;   
    }
</style>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul class="nospace">
        <li><i class="fa fa-phone"></i><?php echo $data->telepon; ?></li>
        <li><i class="fa fa-envelope-o"></i> <?php echo $data->email; ?></li>
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace">
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/"><i class="fa fa-lg fa-home fa-2x"></i></a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/site/login" class="btn bnt-mini btn-info">Login</a></li>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="index.html">LPJU Kabupaten Sleman</a></h1>
      <p>Daerah Istimewa Yogyakarta</p>
<br>
    </div>
  </header>
</div>

<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3" style="margin:10px 30px; width:90%;">
<h1>Daftar Kecamatan</h1>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'kecamatan-grid',
	'dataProvider'=>$model->search(),
	//'filter'=>$model,
	'columns'=>array(
		array('name'=>'no',
                        'type'=>'raw',
                        'header' => 'No ',		
                        'value' => '$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
                        'filter' => '',		
                        ),
		'kecamatan_nama',
		'koordinat',		
	),
)); ?>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <h3 class="heading">LPJU Kab. Sleman</h3>
    <ul class="nospace inline pushright uppercase">
      <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
      <li><a href="#">Contact</a></li>
      <li><a href="#">Login</a></li>
    </ul>
    <div id="copyright">
      <p>Copyright &copy; 2018 - All Rights Reserved 
      
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>

