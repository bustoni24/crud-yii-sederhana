<?php
$this->layout = "front";

?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul class="nospace">
        <li><i class="fa fa-phone"></i><?php echo $data->telepon; ?></li>
        <li><i class="fa fa-envelope-o"></i> <?php echo $data->email; ?></li>
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace">
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/"><i class="fa fa-lg fa-home fa-2x"></i></a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/site/login" class="btn bnt-mini btn-info">Login</a></li>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="index.html">LPJU Kabupaten Sleman</a></h1>
      <p>Daerah Istimewa Yogyakarta</p>
<br>
    </div>
    <!-- 
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="index.html">Home</a></li>
        <li><a class="drop" href="#">Pages</a>
          <ul>
            <li><a href="pages/gallery.html">Gallery</a></li>
            <li><a href="pages/full-width.html">Full Width</a></li>
            <li><a href="pages/sidebar-left.html">Sidebar Left</a></li>
            <li><a href="pages/sidebar-right.html">Sidebar Right</a></li>
            <li><a href="pages/basic-grid.html">Basic Grid</a></li>
          </ul>
        </li>
        <li><a class="drop" href="#">Dropdown</a>
          <ul>
            <li><a href="#">Level 2</a></li>
            <li><a class="drop" href="#">Level 2 + Drop</a>
              <ul>
                <li><a href="#">Level 3</a></li>
                <li><a href="#">Level 3</a></li>
                <li><a href="#">Level 3</a></li>
              </ul>
            </li>
            <li><a href="#">Level 2</a></li>
          </ul>
        </li>
        <li><a href="#">Link Text</a></li>
        <li><a href="#">Link Text</a></li>
      </ul>
    </nav>
    -->
  </header>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper bgded overlay" style="background-image:url('images/demo/background.jpeg'); height:350px;" >
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <article>
      <p class="heading">LPJU</p>
      <h2 class="heading"><span class="block">Kabupaten</span> Sleman</h2>
      <footer> </footer>
    </article>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <div id="services" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="table">
      <div class="table-row"> 
        <!-- ################################################################################################ -->
        <div class="table-cell">
          <article><a href="#"><i class="fa fa-map"></i></a>
            <h6 class="heading">Lokasi LPJU</h6>
            <p>Lokasi LPJU dalam peta wilayah Kabupaten Sleman</p>
            <footer><a href="<?php echo Yii::app()->request->baseUrl;?>/front/map">Selengkapnya &raquo;</a></footer>
          </article>
        </div>
        <div class="table-cell">
          <article><a href="<?php echo Yii::app()->request->baseUrl;?>/front/kecamatan"><i class="fa fa-list-alt"></i></a>
            <h6 class="heading">Daftar Kecamatan</h6>
            <p>Kecamatan yang telah terdata</p>
            <footer><a href="<?php echo Yii::app()->request->baseUrl;?>/front/kecamatan">Selengkapnya &raquo;</a></footer>
          </article>
        </div>
        <div class="table-cell">
          <article><a href="#"><i class="fa fa-envelope"></i></a>
            <h6 class="heading">Lapor Kondisi Lampu</h6>
            <p>Laporkan kerusakan lampu PJU di sekitar Anda</p>
            <footer><a href="#">Selengkapnya &raquo;</a></footer>
          </article>
        </div>
        <!-- ################################################################################################ -->
      </div>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>

<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <h3 class="heading">LPJU Kab. Sleman</h3>
    <ul class="nospace inline pushright uppercase">
      <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
      <li><a href="#">Contact</a></li>
      <li><a href="#">Login</a></li>
    </ul>
<!--
    <ul class="faico clear">
      <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
      <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
      <li><a class="faicon-dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
      <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
      <li><a class="faicon-google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
      <li><a class="faicon-vk" href="#"><i class="fa fa-vk"></i></a></li>
    </ul>
-->
    <div id="copyright">
      <p>Copyright &copy; 2018 - All Rights Reserved 
      
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>
