<?php
/* @var $this RefLampuController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Ref Lampus',
);

$this->menu=array(
	array('label'=>'Create RefLampu', 'url'=>array('create')),
	array('label'=>'Manage RefLampu', 'url'=>array('admin')),
);
?>

<h1>Ref Lampus</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
