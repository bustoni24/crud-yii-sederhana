<?php
/* @var $this RefLampuController */
/* @var $model RefLampu */

$this->breadcrumbs=array(
	'Ref Lampus'=>array('index'),
	$model->ref_lampu_id=>array('view','id'=>$model->ref_lampu_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List RefLampu', 'url'=>array('index')),
	array('label'=>'Create RefLampu', 'url'=>array('create')),
	array('label'=>'View RefLampu', 'url'=>array('view', 'id'=>$model->ref_lampu_id)),
	array('label'=>'Manage RefLampu', 'url'=>array('admin')),
);
?>

<h1>Update RefLampu <?php echo $model->ref_lampu_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>