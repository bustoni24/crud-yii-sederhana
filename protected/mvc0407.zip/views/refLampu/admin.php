<?php
/* @var $this RefLampuController */
/* @var $model RefLampu */

$this->breadcrumbs=array(
	'Ref Lampu'=>array('index')
);

$this->menu=array();

?>

<h1>Referensi Lampu</h1>
<a class="btn btn-success pull-right" href="<?php  echo Yii::app()->request->baseUrl;?>/refLampu/create">Tambah Baru</a>
<br><br>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'ref-lampu-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'ref_lampu_id',
		'jenis_lampu',
		'keterangan',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
