<?php
/* @var $this RefLampuController */
/* @var $model RefLampu */

$this->breadcrumbs=array(
	'Ref Lampus'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List RefLampu', 'url'=>array('index')),
	array('label'=>'Manage RefLampu', 'url'=>array('admin')),
);
?>

<h1>Create RefLampu</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>