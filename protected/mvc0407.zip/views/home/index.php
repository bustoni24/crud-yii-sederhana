<?php
/* @var $this HomeController */

$this->breadcrumbs=array(
	' ',
);

//print_r($model); exit;

?>
<br>
<h1>Dashboard</h1>
<br>
<div class="row">
<?php 
$color = array();
$color[0] = "bg-yellow";
$color[1] = "bg-green";
$color[2] = "bg-red";

$clr = 0;
//foreach($list as $r){
?>

<div class="col-lg-4 ">
         Demo APP<br>LPJU Kabupaten Sleman
        </div>

<?php
//$clr++;
//}
?>
</div>

<?php if(isset(Yii::app()->user->permission) && in_array("administrator",Yii::app()->user->permission)){ ?>
<br>

<br>
<?php } ?>





