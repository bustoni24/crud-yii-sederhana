<?php
/* @var $this AdminSkpiController */
/* @var $model AdminSkpi */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'user-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

  <table>
  <tr>
  <td>	
		Username
	</td>
  <td>	
		<?php echo $form->textField($model,'userUsername',array('size'=>30,'maxlength'=>30)); ?>
		<?php echo $form->error($model,'userUsername'); ?>
	</td>
	</tr>
  <tr>
	<td>
  	Password
  </td>
  <td>
		<input size="15" maxlength="20" name="User[userPassword]" id="User_userPassword" value="" type="password"> <em><?php echo $note  ?></em>
		<?php echo $form->error($model,'userPassword'); ?>
	</td>
	</tr>
	<td>
		Role
		</td>
		<td>
		<?php echo CHtml::activeDropDownList($model, 'userRole', CHtml::listData(Role::model()->findAll(), 'role_id', 'role_name'), array('empty'=>'-- Pilih Role --', 'style'=>'width:120px')); ?> 
		<?php echo $form->error($model,'userRole'); ?>
		</td>	
 
	<tr>
	<td>
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Tambah' : 'Simpan', array('class'=>'btn btn-success')); ?>
	</td>
	</tr>
	</table>

<?php $this->endWidget(); ?>

</div><!-- form -->
