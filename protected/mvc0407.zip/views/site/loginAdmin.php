<?php 
$this->layout = 'login';
?>
<!DOCTYPE html>
<html >
<head>  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <title>Login Form</title>
  
  <link rel="stylesheet" href="xhttps://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link href="<?php echo Yii::app()->request->baseUrl;?>/favicon.ico" rel="SHORTCUT ICON" />
  
      <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/css/login/style.css">

  
</head>

<body>
<div class="caption"><img src="<?php echo Yii::app()->request->baseUrl; ?>/images/light-bulb.png" width="64px"><br>
<span class="title">LPJU Kabupaten Sleman</span>
<br></div>
<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'login-form',
	'enableClientValidation'=>true,
	'clientOptions'=>array(
	'validateOnSubmit'=>false
	),
)); ?>  
  <div class="login">
  <fieldset>
<form>
    <input type="text" placeholder="username" name="LoginForm[username]"/>
  	<input type="password" placeholder="password" name="LoginForm[password]"/>
  </fieldset>
  <input type="submit" value="Log In" />
</form>
  <div class="utilities">
<span class="message" style="float:left;">
<?php  echo $form->error($model,'username'); ?>
<?php echo $form->error($model,'password'); ?>
</span>
  </div>
</div>
  
  <?php $this->endWidget(); ?>
  
</body>
</html>
