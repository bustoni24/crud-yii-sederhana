<?php
/* @var $this DetailLampuController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Detail Lampus',
);

$this->menu=array(
	array('label'=>'Create DetailLampu', 'url'=>array('create')),
	array('label'=>'Manage DetailLampu', 'url'=>array('admin')),
);
?>

<h1>Detail Lampus</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
