<?php
/* @var $this DetailLampuController */
/* @var $model DetailLampu */

$this->breadcrumbs=array(
	'Detail Lampus'=>array('index'),
	$model->detail_lampu_id=>array('view','id'=>$model->detail_lampu_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List DetailLampu', 'url'=>array('index')),
	array('label'=>'Create DetailLampu', 'url'=>array('create')),
	array('label'=>'View DetailLampu', 'url'=>array('view', 'id'=>$model->detail_lampu_id)),
	array('label'=>'Manage DetailLampu', 'url'=>array('admin')),
);
?>

<h1>Update DetailLampu <?php echo $model->detail_lampu_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>