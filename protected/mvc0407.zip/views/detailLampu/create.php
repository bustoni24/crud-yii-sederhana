<?php
/* @var $this DetailLampuController */
/* @var $model DetailLampu */

$this->breadcrumbs=array(
	'Detail Lampus'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List DetailLampu', 'url'=>array('index')),
	array('label'=>'Manage DetailLampu', 'url'=>array('admin')),
);
?>

<h1>Create DetailLampu</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>