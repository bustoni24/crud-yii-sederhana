<?php
/* @var $this DetailLampuController */
/* @var $model DetailLampu */

$this->breadcrumbs=array(
	'Detail Lampu'=>array('index')
);

$this->menu=array(
);

?>

<h1>Detail Lampu</h1>
<a class="btn btn-success pull-right" href="<?php  echo Yii::app()->request->baseUrl;?>/detailLampu/create">Tambah Baru</a>
<br><br>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'detail-lampu-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'detail_lampu_id',
		'jenis_lampu',
		'nama_detail',
		'keterangan',
		'image',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
