
<?php
/* @var $this DesaController */
/* @var $model Desa */

$this->breadcrumbs=array(
	'Desa'=>array('index'),
	'Daftar',
);

$this->menu=array();


?>

<h1>Daftar Desa</h1>
<a class="btn btn-success pull-right" href="<?php  echo Yii::app()->request->baseUrl;?>/desa/create">Tambah Baru</a>
<br><br>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'desa-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'desa_id',
		'desa_nama',
                                'kecamatan_id',
		'koordinat',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
