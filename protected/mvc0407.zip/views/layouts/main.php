<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <title>LPJU Kab. Sleman</title>
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/font-awesome.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/jquery-ui-bootstrap.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/datepicker3.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/material-design-iconic-font.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/bootstrap.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/animate.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/layout.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/components.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/widgets.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/plugins.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/pages.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/bootstrap-extend.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/common.css">
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/responsive.css"> 
    <link type="text/css" rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/small-box.css"> 
   <?php 
        if(isset(Yii::app()->getController()->getAction()->id) && 
                (Yii::app()->getController()->getAction()->id != "admin") && 
                (Yii::app()->getController()->getAction()->id != "lpju")){ ?>
        <script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery.js"></script>
    <?php }?>
    

<link href='http://fonts.googleapis.com/css?family=Racing+Sans+One' rel='stylesheet' type='text/css'>
 
<link href="<?php echo Yii::app()->request->baseUrl;?>/favicon.ico" rel="SHORTCUT ICON" />
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/eModal.min.js"></script> 
    <script type="text/javascript">
function showModal(url){
 eModal.ajax(url, 'Informasi');
}
	</script>


 


<style>
textarea, input[type="text"], input[type="password"], input[type="datetime"], input[type="datetime-local"], input[type="date"], input[type="month"], input[type="time"], input[type="week"], input[type="number"], input[type="email"], input[type="url"], input[type="search"], input[type="tel"], input[type="color"], .uneditable-input {
    background-color: #ffffff;
    border: 1px solid #cccccc;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
    -moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
    -webkit-transition: border linear 0.2s, box-shadow linear 0.2s;
    -moz-transition: border linear 0.2s, box-shadow linear 0.2s;
    -o-transition: border linear 0.2s, box-shadow linear 0.2s;
    transition: border linear 0.2s, box-shadow linear 0.2s;
}

select, textarea, input[type="text"], input[type="password"], input[type="datetime"], input[type="datetime-local"], input[type="date"], input[type="month"], input[type="time"], input[type="week"], input[type="number"], input[type="email"], input[type="url"], input[type="search"], input[type="tel"], input[type="color"], .uneditable-input {
    display: inline-block;
    xheight: 20px;
    padding: 4px 6px;
    margin-bottom: 10px;
    font-size: 12px;
    line-height: 20px;
    color: #555555;
    vertical-align: middle;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
}

h1{
  font: 28px 'Source Sans Pro','Helvetica Neue',Helvetica,Arial,sans-serif !important;
  color:#333;/*#337ab7;*/
  font-weight:bold;
}

.breadcrumbs{
   font-style:italic;
   float:left;
	margin-top: -50px;
}

td{
color:#4d4d4d;
font-size:12px;
}
body{
font-family: 'Source Sans Pro','Helvetica Neue',Helvetica,Arial,sans-serif;
font-weight: 400;
}

.grid-view .button-column {    
    width: 100px;
}

li.next a {
    margin-top: 6px;
    margin-left: 3px;
}

select{
    background: #efefef;
}

.input-group-addon {
    color: #ffffff;    
}
</style>

</head>
<body class="leftbar-view">
<!--Topbar Start Here-->
<header class="topbar clearfix">
    <!--Top Search Bar Start Here-->
    <div class="top-search-bar">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="search-input-addon">
                        <span class="addon-icon"><i class="zmdi zmdi-search"></i></span>
                        <input type="text" class="form-control top-search-input" placeholder="Search">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Top Search Bar End Here-->
    <!--Topbar Left Branding With Logo Start-->
    <div class="topbar-left pull-left">
        <div class="clearfix" >
            <ul class="left-branding pull-left clickablemenu ttmenu dark-style menu-color-gradient">
                <li><span class="left-toggle-switch"><i class="zmdi zmdi-menu" style="color:#ffffff"></i></span></li>
                <li>
                    <div class="logo" style="padding-top:20px; margin-left:30px;">
                        <a href="<?php echo Yii::app()->request->baseUrl;?>" title="Home" style="color:#e4e0fb; padding-top:10px;"><div class="clearfix"><span style="font: 20px 'Source Sans Pro','Helvetica Neue',Helvetica,Arial,sans-serif; font-weight:bold;color:#ffffff; line-height: 0px;">LPJU Kab. Sleman</span></a>
                    </div>
                </li>
            </ul>
            <!--Mobile Search and Rightbar Toggle-->
            <!--<ul class="branding-right pull-right">               
                <li><a href="index.html#" class="btn-mobile-bar"><i class="zmdi zmdi-menu"></i></a></li>
            </ul>                                     --> 
        </div>
    </div>
    <!--Topbar Left Branding With Logo End-->
    <!--Topbar Right Start-->
    <div class="topbar-right pull-right">
         <b>LPJU Kab. Sleman</b> &nbsp;&nbsp;&nbsp;<img src="<?php echo Yii::app()->request->baseUrl;?>/images/logo.png" width="32px"style="padding-top:5px; margin-right: 10px; border-radius:5px;"/>
            <!--Mobile View Leftbar Toggle-->
            <ul class="left-bar-switch pull-left">
                <li><span class="left-toggle-switch"><i class="zmdi zmdi-menu"></i></span></li>
            </ul>
<!--            <ul class="pull-right top-right-icons">
                
                <li class="dropdown apps-dropdown">
                    <a href="index.html#" class="btn-apps dropdown-toggle" data-toggle="dropdown"><i class="zmdi zmdi-apps"></i></a>
                    <div class="dropdown-menu">
                        <ul class="apps-shortcut clearfix">
                          
                            <li>
                                <a href="index.html#"><i class="zmdi zmdi-power"></i>
                                    
                                    <span class="apps-label">Log Out</span>
                                </a>
                            </li>
                        </ul>
                        
                    </div>
                </li>
                 </ul> -->
        </div>
    </div>
    <!--Topbar Right End-->
</header>
<!--Topbar End Here-->

<!--Leftbar Start Here-->
<aside class="leftbar">
    <div class="left-aside-container">
        <div class="user-profile-container">
            
            <div class="admin-bar">
                <ul>
                    <li><a href="<?php echo Yii::app()->request->baseUrl;?>/site/logout"><i class="zmdi zmdi-power" style="color:#efefef; font-size:2em;"></i>
                    </a>
                    </li>
                   
                </ul>
            </div>
        </div>
        <ul class="list-accordion tree-style">
            <?php if(isset(Yii::app()->user->permission)){?>        
            <li><a href="<?php echo Yii::app()->request->baseUrl;?>/home"><i class="zmdi zmdi-home"></i><span class="list-label">Home</span></a></li>
            <?php } ?>

            <?php if(isset(Yii::app()->user->permission) && in_array("user_edit",Yii::app()->user->permission)){ ?>
            <li>
                <a href="#"><i class="zmdi zmdi-key"></i><span class="list-label">Manajemen Pengguna</span></a>
                <ul>
                    <li><a href="<?php echo Yii::app()->request->baseUrl;?>/user">Pengguna</a></li>
                    <li><a href="<?php echo Yii::app()->request->baseUrl;?>/role">Roles</a></li>
                    <li><a href="<?php echo Yii::app()->request->baseUrl;?>/permission">Permissions</a></li>
                </ul>
            </li>
            <?php } ?>

<?php if(isset(Yii::app()->user->permission) && in_array("kecamatan",Yii::app()->user->permission)){?>        
      <li><a href="<?php echo Yii::app()->request->baseUrl;?>/kecamatan"><i class="zmdi zmdi-view-list"></i><span class="list-label">Kecamatan</span></a></li>
<?php } ?>
      
      <?php if(isset(Yii::app()->user->permission) && in_array("desa",Yii::app()->user->permission)){?>        
      <li><a href="<?php echo Yii::app()->request->baseUrl;?>/desa"><i class="zmdi zmdi-view-list"></i><span class="list-label">Desa</span></a></li>
<?php } ?>
      
      <?php if(isset(Yii::app()->user->permission) && in_array("dusun",Yii::app()->user->permission)){?>        
      <li><a href="<?php echo Yii::app()->request->baseUrl;?>/dusun"><i class="zmdi zmdi-view-list"></i><span class="list-label">Dusun</span></a></li>
<?php } ?>
      
      
                  <?php if(isset(Yii::app()->user->permission) && in_array("lampu",Yii::app()->user->permission)){?>        
      <li><a href="<?php echo Yii::app()->request->baseUrl;?>/jenisLampu"><i class="zmdi zmdi-lamp"></i><span class="list-label">Jenis Lampu</span></a></li>
<?php } ?>
      
            <?php if(isset(Yii::app()->user->permission) && in_array("lampu",Yii::app()->user->permission)){?>        
      <!--<li><a href="<?php echo Yii::app()->request->baseUrl;?>/detailLampu"><i class="zmdi zmdi-lamp"></i><span class="list-label">Detail Lampu</span></a></li>-->
<?php } ?>
      
      
      <?php if(isset(Yii::app()->user->permission) && in_array("lampu",Yii::app()->user->permission)){?>        
      <li><a href="<?php echo Yii::app()->request->baseUrl;?>/dataLampu"><i class="zmdi zmdi-lamp"></i><span class="list-label">Data LPJU</span></a></li>
<?php } ?>
            
<?php if(isset(Yii::app()->user->permission) && in_array("settings",Yii::app()->user->permission)){?>        
      <li><a href="<?php echo Yii::app()->request->baseUrl;?>/laporan"><i class="zmdi zmdi-file"></i><span class="list-label">Laporan</span></a></li>
<?php } ?>
      
<?php if(isset(Yii::app()->user->permission) && in_array("settings",Yii::app()->user->permission)){?>        
      <li><a href="<?php echo Yii::app()->request->baseUrl;?>/settings"><i class="zmdi zmdi-settings"></i><span class="list-label">Settings</span></a></li>
<?php } ?>

     
		</ul>
    </div>
</aside>
<!--Leftbar End Here-->
<!--Page Container Start Here-->
<section class="main-container" id="maincont">
<div class="container-fluid">
<div class="page-header filled full-block light">
    <div class="row">
<?php if(isset($this->breadcrumbs)):?>
		<?php $this->widget('zii.widgets.CBreadcrumbs', array(
			'links'=>$this->breadcrumbs,
		)); ?><!-- breadcrumbs -->
	<?php endif?>
	
<?php echo $content; ?>
    </div>
</div>
</div>
</div>


</section>
<!--Page Container End Here-->

<!--Footer Start Here -->
<footer class="footer-container">
    <div class="container-fluid">
        <div class="row">
            
                <div class="footer-right pull-right">
                    <span style="color:#f2f3f5">© 2018 LPJU Kab. Sleman</span>
                </div>
            
           
        </div>
    </div>
</footer>
<!--Footer End Here -->


<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery-migrate.jsx"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/bootstrap.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery.ui.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jRespond.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/nav.accordion.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/hover.intent.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/hammerjs.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/scrollup.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery.slimscroll.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery.hammer.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery.fitvids.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery.syntaxhighlighter.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/velocity.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery-jvectormap.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery-jvectormap-world-mill.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/jquery-jvectormap-us-aea.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/lib/smart-resize.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl;?>/js/apps.js"></script>
</body>
</html>
