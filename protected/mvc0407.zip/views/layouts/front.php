<!DOCTYPE html>
<!--
Template Name: Corklow
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
<head>
<title>LPJU Kab. Sleman</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="<?php echo Yii::app()->request->baseUrl; ?>/layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo Yii::app()->request->baseUrl;?>/favicon.ico" rel="SHORTCUT ICON" />
</head>
<body id="top">
<?php 
/*
$lang = Yii::app()->language='en'; 
Yii::app()->setLanguage($lang);
echo Yii::t('xxx','yyyy');
*/
echo $content; ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>
