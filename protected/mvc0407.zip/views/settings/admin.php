<?php
/* @var $this SettingsController */
/* @var $model Settings */

$this->breadcrumbs=array(
	'Settings'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'Settings', 'url'=>array('index')),
);


?>

<h1>Pengaturan Situs</h1>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'settings-grid',
	'dataProvider'=>$model->search(),
	//'filter'=>$model,
	'columns'=>array(
		'telepon',
		'email',
		'about',
		'alamat',
		'banner_image_url',
		array(
			//'name'=>'',
			'header'=>'Action', //column header
			'type' =>'raw',
			'value' =>
			'CHtml::link("<i class=\"fa fa-edit \" style=\"margin-top:3px;\"></i> ",
						Yii::app()->request->baseUrl."/settings/update/".$data->setting_id,
						array("class"=>"btn btn-mini", "style"=>"color:#333333; margin-bottom:3px; margin-right:5px;"))',
			'htmlOptions'=>array('width'=>'200px', 'style'=>'text-align:center;')
		),
	),
)); ?>
