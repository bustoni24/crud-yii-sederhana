<?php
/* @var $this KecamatanController */
/* @var $model Kecamatan */

$this->breadcrumbs=array(
	'Kecamatan'=>array('index'),
	'Daftar',
);

$this->menu=array();


?>

<h1>Daftar Kecamatan</h1>
<a class="btn btn-success pull-right" href="<?php  echo Yii::app()->request->baseUrl;?>/kecamatan/create">Tambah Baru</a>
<br><br>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'kecamatan-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		array('name'=>'no',
                        'type'=>'raw',
                        'header' => 'No ',		
                        'value' => '$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
                        'filter' => '',		
                        ),
		'kecamatan_nama',
		'koordinat',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
