<?php

class LaporanController extends Controller
{
                public $layout='main';
                
	public function actionIndex()
	{
		$this->redirect(array('lpju'));
	}

	public function actionLpju()
	{

                            $model = new DataLampu('search');
                        $model->unsetAttributes();  // clear any default values
                        if (isset($_GET['DataLampu']))
                            $model->attributes = $_GET['DataLampu'];

                        $this->render('admin', array(
                            'model' => $model,
                        ));
	}
        
        public  function getJenisLampu($id){
                $refLampu = JenisLampu::model()->find('ref_lampu_id = :id', array(':id'=>$id));
                if($refLampu != null){
                     return $refLampu->jenis_lampu;
                }
                
                return "";
        }
        
         public  function getKecamatan($id){
                $kecamatan = Kecamatan::model()->find('kecamatan_id = :id', array(':id'=>$id));
                if($kecamatan != null){
                     return $kecamatan->kecamatan_nama;
                }
                
                return "";
        }
        
        public  function getDesa($id){
                $desa = Desa::model()->find('desa_id = :id', array(':id'=>$id));
                if($desa != null){
                     return $desa->desa_nama;
                }
                
                return "";
        }

	// Uncomment the following methods and override them if needed
	/*
	public function filters()
	{
		// return the filter configuration for this controller, e.g.:
		return array(
			'inlineFilterName',
			array(
				'class'=>'path.to.FilterClass',
				'propertyName'=>'propertyValue',
			),
		);
	}

	public function actions()
	{
		// return external action classes, e.g.:
		return array(
			'action1'=>'path.to.ActionClass',
			'action2'=>array(
				'class'=>'path.to.AnotherActionClass',
				'propertyName'=>'propertyValue',
			),
		);
	}
	*/
}