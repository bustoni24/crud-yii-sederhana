<?php
/* @var $this DesaController */
/* @var $model Desa */

$this->breadcrumbs=array(
	'Desas'=>array('index'),
	$model->desa_id=>array('view','id'=>$model->desa_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List Desa', 'url'=>array('index')),
	array('label'=>'Create Desa', 'url'=>array('create')),
	array('label'=>'View Desa', 'url'=>array('view', 'id'=>$model->desa_id)),
	array('label'=>'Manage Desa', 'url'=>array('admin')),
);
?>

<h1>Update Desa <?php echo $model->desa_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>