<?php
/* @var $this KecamatanController */
/* @var $model Kecamatan */

$this->breadcrumbs=array(
	'Kecamatans'=>array('index'),
	$model->kecamatan_id=>array('view','id'=>$model->kecamatan_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List Kecamatan', 'url'=>array('index')),
	array('label'=>'Create Kecamatan', 'url'=>array('create')),
	array('label'=>'View Kecamatan', 'url'=>array('view', 'id'=>$model->kecamatan_id)),
	array('label'=>'Manage Kecamatan', 'url'=>array('admin')),
);
?>

<h1>Update Kecamatan <?php echo $model->kecamatan_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>