<?php
/* @var $this LaporanController */

$this->breadcrumbs=array(
	'Laporan'=>array('/laporan'),
	'Lpju',
);
?>
<h1>Laporan Data LPJU</h1>

<table class="table">
    <tr>
        <td>ID</td>
        <td>X</td>
        <td>Y</td>
        <td>NAMA JALAN</td>
        <td>DESA</td>
        <td>KECAMATAN</td>
        <td>JENIS LAMPU</td>
        <td>DAYA(Watt)</td>
        <td>JENIS TIANG</td>
        <td>TANGGAL PEMASANGAN</td>
        <td>KWH-METER</td>
        <td>LEGALITAS LAMPU</td>
        <td>ID RUAS JALAN</td>        
        <td>KELAS JALAN</td>
        <td>KETERANGAN</td>
        
    </tr>
<?php
//print_r($data);
foreach ($data as $r){
   echo  "<tr>";
   echo  "<td>";
   echo $r->kode;
   echo  "</td>";
   echo  "<td>";
   echo $r->lat;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->lng;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->nama_jalan;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->dusun_id;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->kecamatan_id;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->detail_lampu;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->daya;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->jenis_tiang;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->tanggal_pasang;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->kwh_meter;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->is_legal;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->id_ruas_jalan;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->kelas_jalan;
   echo  "</td>";
   
   echo  "<td>";
   echo $r->keterangan;
   echo  "</td>";
   
   echo  "</tr>";
}
?>

</table>