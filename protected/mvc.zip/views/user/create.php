<?php
/* @var $this AdminSkpiController */
/* @var $model AdminSkpi */

$this->breadcrumbs=array(
	'User'=>array('index'),
	'Create',
);

// $this->menu=array(
// 	array('label'=>'List AdminSkpi', 'url'=>array('index')),
// 	array('label'=>'Manage AdminSkpi', 'url'=>array('admin')),
// );
?>

<h1>Tambah Pengguna</h1>

<?php $this->renderPartial('_form', array('model'=>$model, 'note'=>' ')); ?>