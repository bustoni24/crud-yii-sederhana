<?php
/* @var $this DataLampuController */
/* @var $model DataLampu */
/* @var $form CActiveForm */
?>

<style>
    td{
        padding:3px;
    }
</style>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'data-lampu-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	
	<?php echo $form->errorSummary($model); ?>
        <table>
	<tr class="xrow">
		<td style="width:150px;"><?php echo $form->labelEx($model,'kode'); ?></td>
		<td><?php echo $form->textField($model,'kode',array('size'=>30,'maxlength'=>30)); ?></td>
		<td><?php echo $form->error($model,'kode'); ?></td>
	</tr>
                
                 <tr class="xrow">
		<td><?php echo $form->labelEx($model,'lat'); ?></td>
		<td><?php echo $form->textField($model,'lat',array('size'=>30,'maxlength'=>30)); ?></td>
		<td><?php echo $form->error($model,'lat'); ?></td>
	</tr>

	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'lng'); ?></td>
		<td><?php echo $form->textField($model,'lng',array('size'=>30,'maxlength'=>30)); ?></td>
		<td><?php echo $form->error($model,'lng'); ?></td>
	</tr>
	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'kecamatan_id'); ?></td>
                <td><?php echo $form->dropDownList($model, 'kecamatan_id', CHtml::listData(Kecamatan::model()->findAll(array('order' => 'kecamatan_nama asc')), 'kecamatan_id', 'kecamatan_nama'), array('empty'=>' - ', 'style'=>'width:150px')); ?></td>
		<td><?php echo $form->error($model,'kecamatan_id'); ?></td>
	</tr>

	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'dusun_id'); ?></td>
                <td><?php echo $form->dropDownList($model, 'dusun_id', 
                        CHtml::listData(Desa::model()->findAll(array('order' => 'desa_nama asc')), 'desa_id', 'desa_nama'), array('empty'=>' - ', 'style'=>'width:150px')); ?></td>
		<td><?php echo $form->error($model,'dusun_id'); ?></td>
	</tr>

        
	<tr class="xrow">
		<td>Jenis Lampu</td>
                <td><?php echo $form->dropDownList($model, 'detail_lampu', CHtml::listData(JenisLampu::model()->findAll(array('order' => 'ref_lampu_id asc')), 'ref_lampu_id', 'jenis_lampu'), array('empty'=>' - ', 'style'=>'width:150px')); ?></td>
		<td><?php echo $form->error($model,'detail_lampu'); ?></td>
	</tr>

	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'daya'); ?></td>
		<td><?php echo $form->textField($model,'daya'); ?></td>
		<td><?php echo $form->error($model,'daya'); ?></td>
	</tr>

	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'jenis_tiang'); ?></td>
		<td><?php echo $form->dropDownList($model, 'jenis_tiang', array('Tiang Bulat' => 'Tiang Bulat', 'Tiang Oktagonal' => 'Tiang Oktagonal', 'Stang' => 'Stang'), 
                                        array('style' => 'width:120px')); ?></td>
		<td><?php echo $form->error($model,'jenis_tiang'); ?></td>
	</tr>

               
	

	<tr class="xrow">
            <td>
            <?php echo $form->labelEx($model,'tanggal_pasang'); ?>
            </td>
            <td>
			<?php $this->widget('zii.widgets.jui.CJuiDatePicker', 
			   array('model' => $model,
                                                    'name' => 'tanggal_pasang',
                                                    'attribute' => 'tanggal_pasang',
                                                    'htmlOptions' => array('size' => '10',
                                                                                            'maxlength' => '10',
                                                                                            'placeholder'=>' yyyy-mm-dd',
                                                                                            'class'=>'span2',												
                                                                                            'required'=>'required'),
                                                    'options' => array ('dateFormat' => 'yy-mm-dd',
                                                                            'autoclose' => true,
                                                                            'changeMonth'=>true,
                                                                            'changeYear'=> true,
                                                                            'yearRange' => '1945:'.date('Y'),
                                                                            'minDate' => date('Y-m-d'),
                                                                            //'maxDate' => date('Y-m-d'),
                                                                   ),
			));	?>
                </td>
                <td>
			<?php echo $form->error($model,'tanggal_pasang'); ?>
                </td>
		
	</tr>

	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'kwh_meter'); ?></td>
		<td><?php echo $form->textField($model,'kwh_meter'); ?></td>
		<td><?php echo $form->error($model,'kwh_meter'); ?></td>
	</tr>

	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'id_ruas_jalan'); ?></td>
		<td><?php echo $form->textField($model,'id_ruas_jalan',array('size'=>50,'maxlength'=>50)); ?></td>
		<td><?php echo $form->error($model,'id_ruas_jalan'); ?></td>
	</tr>
        
                <tr class="xrow">
		<td><?php echo $form->labelEx($model,'nama_jalan'); ?></td>
		<td><?php echo $form->textField($model,'nama_jalan',array('size'=>50,'maxlength'=>50)); ?></td>
		<td><?php echo $form->error($model,'nama_jalan'); ?></td>
	</tr>

	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'kelas_jalan'); ?></td>
		<td><?php echo $form->dropDownList($model, 'kelas_jalan', array('Nasional' => 'Nasional', 'Nasional K' => 'Nasional K', 
                                    'Propinsi' => 'Propinsi K', 'Kabupaten' => 'Kabupaten', 'Desa/Pemukiman' => 'Desa/Pemukiman'), 
                                        array('style' => 'width:120px')); ?></td>
		<td><?php echo $form->error($model,'kelas_jalan'); ?></td>
	</tr>

	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'keterangan'); ?></td>
		<td><?php echo $form->textArea($model,'keterangan',array('xrows'=>6, 'cols'=>50)); ?></td>
		<td><?php echo $form->error($model,'keterangan'); ?></td>
	</tr>

	<tr class="xrow">
		<td><?php echo $form->labelEx($model,'is_legal'); ?></td>
		<td><?php echo $form->dropDownList($model, 'is_legal', array('1' => 'Legal', '0' => 'Ilegal'), 
                                        array('style' => 'width:100px')); ?></td>
		<td><?php echo $form->error($model,'is_legal'); ?></td>
	</tr>

	<tr class="xrow buttons">
		<td><?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?></td>
	</tr>
        </table>

<?php $this->endWidget(); ?>

</div><!-- form -->