<?php
/* @var $this DataLampuController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Data Lampus',
);

$this->menu=array(
	array('label'=>'Create DataLampu', 'url'=>array('create')),
	array('label'=>'Manage DataLampu', 'url'=>array('admin')),
);
?>

<h1>Data Lampus</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
