<?php
/* @var $this DataLampuController */
/* @var $model DataLampu */

$this->breadcrumbs=array(
	'Data Lampus'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'List DataLampu', 'url'=>array('index')),
	array('label'=>'Create DataLampu', 'url'=>array('create')),
);


?>

<h1>Data Lampu</h1>
<a class="btn btn-success pull-right" href="<?php  echo Yii::app()->request->baseUrl;?>/dataLampu/create">Tambah Baru</a>
<br><br>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'data-lampu-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
                        array('name'=>'no',
                        'type'=>'raw',
                        'header' => 'No ',		
                        'value' => '$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
                        'filter' => '',		
                        ),
                        array('name'=>'detail_lampu',
		'type'=>'raw',
		'header' => 'Jenis',		
		'value' => '$this->grid->getController()->getJenisLampu($data->detail_lampu)',
                            'filter' =>CHtml::listData(JenisLampu::model()->findAll() ,'ref_lampu_id','jenis_lampu')
		),
            
                        'kode',
                        'daya',
                        array('name'=>'jenis_tiang',
		'type'=>'raw',
		'header' => 'Jenis Tiang',		
		'value' => '$data->jenis_tiang',
                           'filter'=>array('Tiang Bulat' => 'Tiang Bulat', 'Tiang Oktagonal' => 'Tiang Oktagonal', 'Stang' => 'Stang'),  	
                        ),
                        array('name'=>'kecamatan_id',
		'type'=>'raw',
		'header' => 'Kecamatan',		
		'value' => '$this->grid->getController()->getKecamatan($data->kecamatan_id)',
                            'filter' =>CHtml::listData(Kecamatan::model()->findAll() ,'kecamatan_id','kecamatan_nama')	
                        ),
                        array('name'=>'dusun_id',
		'type'=>'raw',
		'header' => 'Desa',		
		'value' => '$this->grid->getController()->getDesa($data->dusun_id)',
                                'filter' =>CHtml::listData(Desa::model()->findAll() ,'desa_id','desa_nama')
                        ),                     
                        'tanggal_pasang',
                        'kwh_meter',
                        'id_ruas_jalan',
             array('name'=>'kelas_jalan',
		'type'=>'raw',
		'header' => 'Kelas Jalan',		
		'value' => '$data->kelas_jalan',
                            'filter'=>array('Nasional' => 'Nasional', 'Nasional K' => 'Nasional K', 
                                    'Propinsi' => 'Propinsi K', 'Kabupaten' => 'Kabupaten', 'Desa/Pemukiman' => 'Desa/Pemukiman'),  
                        ),
                        'keterangan',
                        array('name'=>'is_legal',
		'type'=>'raw',
		'header' => 'Legalitas',		
		'value' => '$data->is_legal == 1?"Legal":"Ilegal" ',
                            'filter'=>array('1'=>'Legal','0'=>'Ilegal'),  
                        ),
                        array(
			'class'=>'CButtonColumn',
		),
		
	),
)); ?>
