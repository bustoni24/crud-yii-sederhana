<?php
/* @var $this DusunController */
/* @var $model Dusun */

$this->breadcrumbs=array(
	'Dusun'=>array('index'),
	'Daftar',
);

$this->menu=array();

?>

<h1>Daftar Dusun</h1>
<a class="btn btn-success pull-right" href="<?php  echo Yii::app()->request->baseUrl;?>/dusun/create">Tambah Baru</a>
<br><br>
    <?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'dusun-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'dusun_id',
		'dusun_nama',
                                'desa_id',
		'koordinat',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
